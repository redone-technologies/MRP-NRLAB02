#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <sched.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include <math.h>
#include <sys/fcntl.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <sys/stat.h>
#include <termios.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "ros/ros.h"
#include "sensor_msgs/Joy.h"
#include <sensor_msgs/Imu.h>
#include "sensor_msgs/MagneticField.h"
#include "std_msgs/String.h"
#include "std_msgs/UInt8.h"
#include "geometry_msgs/Twist.h"
#include "nrlab_sensor_msgs.h"
#include <dynamic_reconfigure/server.h>
#include <dynamic_reconfigure/DoubleParameter.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/Config.h>

#include "nrlab02_ParamsConfig.h"

#include "libnrlab02.h"

T_SENSOR_DATA _sensor;

void velCallback(const geometry_msgs::Twist::ConstPtr& msg)
{
	int r = RWrite_2W_Kienmatics(msg->linear.x, msg->angular.z);
	ROS_INFO("sub cmd [%d] : %.4f, %.4f",r, msg->linear.x, msg->angular.z);
}

void configCallBack(mrp_nrlab02::nrlab02_ParamsConfig &config, uint32_t level) 
{
	RWrite_SetMaxLineSpeed(config.MAX_LINE_SPEED);
	MWrite_SetProfileAcceleration(config.PROFILE_ACCELERATION);
	ROS_INFO("Change parameters : %f, %d",config.MAX_LINE_SPEED, config.PROFILE_ACCELERATION);
}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "nrlab_node");

	ros::NodeHandle n;
	ros::Subscriber cmd_sub = n.subscribe("/nrlab/cmd_vel", 1000, velCallback);
	ros::Publisher pub = n.advertise<mrp_nrlab02::nrlab_sensor_msgs>("/nrlab/sensor", 1000);

	dynamic_reconfigure::Server<mrp_nrlab02::nrlab02_ParamsConfig> dr_srv;
	dynamic_reconfigure::Server<mrp_nrlab02::nrlab02_ParamsConfig>::CallbackType cb;
	cb = boost::bind(&configCallBack, _1, _2); 
	dr_srv.setCallback(cb);


	ros::Rate loop_rate(100);
	
	std::string s;

    if (ros::param::get("/nrlab_node/robot_ip", s))
    {
      ROS_INFO("Got param: %s", s.c_str());
    }
    else
    {
      ROS_ERROR("Failed to get param 'robot_ip'");
      ros::shutdown();
    }
    
    double maxlinespeed;
    if (ros::param::get("/nrlab_node/max_line_speed", maxlinespeed))
    {
      ROS_INFO("Got param: %f", maxlinespeed);
    }
    else
    {
      ROS_ERROR("Failed to get param 'max_line_speed'");
      ros::shutdown();
    }

    int profileAccel;
    if (ros::param::get("/nrlab_node/motor_profile_Acceleration", profileAccel))
    {
      ROS_INFO("Got param: %d", profileAccel);
    }
    else
    {
      ROS_ERROR("Failed to get param 'motor_profile_Acceleration'");
      ros::shutdown();
    }

	if(NWrite_EnableNetwork((char*)s.c_str()) != SUCCESS)
		ROS_INFO("MRP-NRLAB02 Connection Failed");

	RWrite_SetMaxLineSpeed(maxlinespeed);
	MWrite_SetProfileAcceleration(profileAccel);

	mrp_nrlab02::nrlab02_ParamsConfig config;
	config.MAX_LINE_SPEED = maxlinespeed;
	config.PROFILE_ACCELERATION = profileAccel;
	dr_srv.updateConfig(config);



	while(ros::ok())
	{
		ros::spinOnce();
		if(SRead_SensorData(_sensor) == SUCCESS)
		{
			mrp_nrlab02::nrlab_sensor_msgs msg = mrp_nrlab02::nrlab_sensor_msgs();
			msg.header.stamp = ros::Time::now();
			msg.header.frame_id = "nrlab";

			for(int i=0 ; i<7 ; i++)
				msg.psd[i] 	= _sensor.psd[i];
			MRead_MotorPosition(msg.encoder_l, msg.encoder_r);
			MRead_MotorVelocity(msg.motor_rpm_l, msg.motor_rpm_r);
			RRead_2W_Kinematics(msg.tv, msg.rv);
			msg.x		= _sensor.x;
			msg.y		= _sensor.y;
			msg.z		= _sensor.z;
			msg.w		= _sensor.w;
			msg.ax		= _sensor.ax;
			msg.ay		= _sensor.ay;
			msg.az		= _sensor.az;
			msg.gx		= _sensor.gx;
			msg.gy		= _sensor.gy;
			msg.gz		= _sensor.gz;
			msg.mx		= _sensor.mx;
			msg.my  	= _sensor.my;
			msg.mz		= _sensor.mz;
			msg.temp	= _sensor.temp;
			pub.publish(msg);

		}else
		{
			ROS_ERROR("CONNECTIONSTATE_FAULTED");
		}

		loop_rate.sleep();
	}

	return 0;
}




